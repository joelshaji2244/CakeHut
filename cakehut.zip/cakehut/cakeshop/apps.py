from django.apps import AppConfig


class CakeshopConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cakeshop'
